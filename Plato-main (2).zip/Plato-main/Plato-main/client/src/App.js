import './App.css';
import {Routes,Route} from 'react-router-dom'


import Generalhomepage from './Components/Generalhomepage/Generalhomepage';
//import Navbar from './Components/Navbar/Navbar';
//for user
import UserHomePage from './Components/User/UserHomePage';
import UserSignInPage from './Components/User/UserSignInPage'
import UserSignUpPage from './Components/User/UserSignUpPage'
import UserOtpScreen from './Components/User/UserOtpScreen'
import UserNewAccountPage from './Components/User/UserNewAccountPage'
import UserDetailsForm from './Components/User/UserDetailsForm'
import UserSetPasswordPage from './Components/User/UserSetPasswordPage';
//consultant routes
import ConsultantDetailsForm from './Components/Consultant/ConsultantDetailsForm'
import ConsultantNewAccountPage from './Components/Consultant/ConsultantNewAccountPage'
import ConsultantOTPScreen  from './Components/Consultant/ConsultantOTPScreen'
import ConsultantSigninPage  from './Components/Consultant/ConsultantSigninPage'
import ConsultantSignupPage  from './Components/Consultant/ConsultantSignupPage'
import ConsultantThankyouPage  from './Components/Consultant/ConsultantThankyouPage'
import ConsultantSetPasswordPage from './Components/Consultant/ConsultantSetPasswordPage'
import ConsultantAdditionalDetailsForm from './Components/Consultant/ConsultantAdditionalDetailsForm'
import ConsultantCriticalDetails from './Components/Consultant/ConsultantCriticalDetails';
import ConsultantPaymentDetails from './Components/Consultant/ConsultantPaymentDetails'
//contact us route
import ContactUs from './Components/ContactUs'
import VideoCallScreen from './Components/VideoCallScreen';
import ChatScreen from './Components/ChatSystem/ChatScreen';
import ConsultationRequest from './Components/UserConsultantRequest';
import ThankYou from './Components/UserThankYou';
import Footer from './Components/FooterSeaWireFooter';
import BuyPremiumMonthly from './Components/UserBuyPremiumMonthly';
import BuyPremiumYearly from './Components/UserBuyPremiumYearly';
import AnimationThankYou from './Components/UserAnimationThankyou';
import GetConsultation from './Components/UserGetConsultation';
//reset password routes
import ResetPassword from './Components/ResetPassword';
import CheckYourMail from './Components/CheckYourMail'; 
import CreatePassword  from './Components/CreatePassword';

//profile details
import UserProfile from './Components/UserProfile';
import ConsultantProfileBasicDetails from './Components/ConsultantProfileBasicDetails';
import UserProfileWithNo from './Components/UserProfileWithNo'
import ConsultantProfile from './Components/ConsultantProfile';
import ConsultantBasicProfileDetailsIncompleteProfile from './Components/ConsultantBasicDetailsIncompletProfile';

function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Generalhomepage/>}/>
        <Route exact path='/contactus' element={<ContactUs/>} />
        <Route exact path="/videocall" element={<VideoCallScreen/>} />
        <Route exact path="/mychats" element={<ChatScreen/>} />
        {/** for user routes */}
        <Route exact path="/user/home-page" element={<UserHomePage/>} />
        <Route exact path="/user/signin" element={<UserSignInPage/>}/>
        <Route exact path="/user/signup" element={<UserSignUpPage/>}/>
        <Route exact path="/user/otp" element={<UserOtpScreen/>}/>
        <Route exact path="/user/account-page" element={<UserNewAccountPage/>}/>
        <Route exact path="/user/detailsform" element={<UserDetailsForm/>}/>
        <Route exact path="/user/set-password" element={<UserSetPasswordPage/>} />
        {/**for consultant */}
        <Route exact path="/consultant/signin" element={<ConsultantSigninPage/>} />
        <Route exact path="/consultant/signup" element={<ConsultantSignupPage/>} />
        <Route exact path="/consultant/otp" element={<ConsultantOTPScreen/>} />
        <Route exact path="/consultant/account-page" element={<ConsultantNewAccountPage/>} />
        <Route exact path="/consultant/detailsform" element={<ConsultantDetailsForm/>} />
        <Route exact path="/consultant/thankyou" element={<ConsultantThankyouPage/>} />
        <Route exact path ="/consultant/set-password" element={<ConsultantSetPasswordPage/>} />
        <Route exact path="/consultant/additional-details" element={<ConsultantAdditionalDetailsForm/>} />
        <Route exact path="/consultant/critical-details" element={<ConsultantCriticalDetails/>} />
        <Route exact path="/consultant/payment-details" element={<ConsultantPaymentDetails/>} />
        <Route exact path="/thankyou" element={<ThankYou/>}/>
        <Route exact path="/consulation/request" element={<ConsultationRequest/>}/>
        <Route exact path="/buypremium/monthly" element={<BuyPremiumMonthly/>}/>
        <Route exact path="/buypremium/yearly" element={<BuyPremiumYearly/>}/>
        <Route export path="/getconsult" element={<GetConsultation/>}/>
        <Route exact path="/animation" element={<AnimationThankYou/>}/>
        <Route exact path="/Footer" element={<Footer/>}/>
        {/**reset password */}
        <Route path="/reset-password" component={<ResetPassword/>}/>
        <Route path="/check-mail" component={<CheckYourMail/>} /> 
        <Route path="/create-password" component={<CreatePassword/>}/>
        {/**profile routes */}
        <Route exact path="/user-profile" element={<UserProfile/>}/>
        <Route exact path="consultant/basic/profile" element={<ConsultantProfileBasicDetails/>}/>
        <Route exact path='/profile/no' element={<UserProfileWithNo/>}/>
        <Route exact path='/consultant-profile' element={<ConsultantProfile/>} />
        <Route exact path='/consultant-to-be-update-profile' element={<ConsultantBasicProfileDetailsIncompleteProfile/>} />
      </Routes>
      </>
  );
}

export default App;
