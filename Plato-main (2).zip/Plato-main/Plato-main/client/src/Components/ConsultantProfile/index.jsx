import React,{useState} from 'react'
import { FaArrowLeft } from "react-icons/fa";
import {v4 as uuidv4} from 'uuid'
import ConsultantProfileReviewItem from '../ConsultantProfileReviewItem';
import './index.css'

const ConsultantProfile = () => {
  const reviews = [
    {
      id : uuidv4(),
      userName : 'Thor Ragnorak',
      ratingImg : '',
      userReviewDesc  : 'lorem ipsum lorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsum',
      userReviewdDate : 'May 28, 2024',
      isHelpFull : 2,
      notHelpfull : 0,
    },
    {
      id : uuidv4(),
      userName : 'Thor Ragnorak',
      ratingImg : '',
      userReviewDesc  : 'lorem ipsum lorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsum',
      userReviewdDate : 'May 28, 2024',
      isHelpFull : 2,
      notHelpfull : 0,
    }
  ]
  
  return (
    <div className='consultant-profile-bg-container'>
        <div className='consultant-profile-button-container'>
          <button className='consultant-profile-back-btn'><FaArrowLeft/></button>
          <h2 className='consultant-profile-heading'>Consultant Profile</h2>
        </div>
        <div className='consultant-profile-main-container'>
          {/** consultant profile details */}
          <div className='consultant-profile-details-card'>
            <img
              src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1717255741/Outline_jlkelm.svg"
              className='share-btn'
              alt="share"
            />
            {/** consultant profile img fields */}
            <div className='consultant-profile-photo-container'>
              <img
                className='consultant-profile-img'
                alt="profile-img"
                src='https://res.cloudinary.com/dgl0v7vwf/image/upload/v1717255642/86efa3df337e8c215dd8095476bb6513_ygqdhz.jpg'
              />
              <h4 className='consultant-profile-name'>John Doe</h4>
            </div>
            {/** consultant description */}
            <div>
            <p className='consultant-profile-description'>
            Lorem Lorem Ipsum Lorem Ipsum Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum...
            </p>
            </div>
            <div>
              {/** consultant education passedout instituion name */}
              <p className='consultant-profile-description'>XYX School</p>
              {/** consultant experience */}
              <p className='consultant-profile-experience'>14+ Experience</p>
              {/**consultant specialities */}
            </div>
            <div className='consultant-expertise-function-container'>
              <div className='consultant-speciality-card'>
                {/** expertise details */}
                <p className='consultant-profile-description'>Expertise</p>
                <div className='consultant-profile-specialties-list'>
                  <li className='consultant-profile-speciality-item'>Human Resource</li>
                  <li className='consultant-profile-speciality-item'>Operation</li>
                  <li className='consultant-profile-speciality-item'>Operations</li>
                </div>
              </div>
              <div className='consultant-speciality-card'>
                {/** industry details */}
                <p className='consultant-profile-description'>Industry</p>
                <div className='consultant-profile-specialties-list'>
                  <li className='consultant-profile-speciality-item'>Infrastructure</li>
                  <li className='consultant-profile-speciality-item'>Energy</li>
                  <li className='consultant-profile-speciality-item'>Aviation</li>
                </div>
              </div>
              <div className='consultant-speciality-card'>
                {/** functions details */}
                <p className='consultant-profile-description'>Functions</p>
                <div className='consultant-profile-specialties-list'>
                  <li className='consultant-profile-speciality-item'>Legal</li>
                  <li className='consultant-profile-speciality-item'>Finance</li>
                  <li className='consultant-profile-speciality-item'>Company Secretarial</li>
                </div>
              </div>
            </div>
            <div>
              {/** middle management */}
            <p className='consultant-profile-description'>Middle Management</p>
            {/** number of consultantions */}
            <p className='consultantion-profile-no-of-consultations'>204 Consultations</p>
            </div>
            {/** recommendations and rating */}
            <div className='consultation-profile-recommendation-container'>
              {/** recommendation percentage */}
              <div className='consultation-profile-recommendation-card'>
                <div className='consultaion-profile-recommendation-details'>
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="65" viewBox="0 0 64 65" fill="none">
                  <path d="M61.3327 27.4983C61.3327 26.0838 60.7708 24.7272 59.7706 23.7271C58.7704 22.7269 57.4138 22.165 55.9994 22.165H39.146L41.706 9.97829C41.7593 9.71162 41.786 9.41829 41.786 9.12496C41.786 8.03162 41.3327 7.01829 40.6127 6.29829L37.786 3.49829L20.2393 21.045C19.2527 22.0316 18.666 23.365 18.666 24.8316V51.4983C18.666 52.9128 19.2279 54.2693 20.2281 55.2695C21.2283 56.2697 22.5849 56.8316 23.9993 56.8316H47.9994C50.2127 56.8316 52.106 55.4983 52.906 53.5783L60.9594 34.7783C61.1994 34.165 61.3327 33.525 61.3327 32.8316V27.4983ZM2.66602 56.8316H13.3327V24.8316H2.66602V56.8316Z" fill="#21BF73"/>
                  </svg>
                  <h1 className='consultation-profile-percentage'>94%</h1>
                </div>
                <p className='consultant-profile-description'>User Recommendation</p>
              </div>
              {/** recommendation rating */}
              <div className='consultation-profile-recommendation-card'>
                <div className='consultaion-profile-recommendation-details'>
                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="65" viewBox="0 0 64 65" fill="none" margin-right="20px">
                <path d="M30.7575 6.01992C31.2665 4.98844 32.7374 4.98843 33.2464 6.01991L40.4958 20.7088C40.698 21.1184 41.0887 21.4023 41.5408 21.468L57.7509 23.8234C58.8892 23.9888 59.3437 25.3877 58.52 26.1906L46.7903 37.6243C46.4632 37.9431 46.3139 38.4025 46.3911 38.8527L49.1602 54.9973C49.3546 56.131 48.1646 56.9955 47.1465 56.4603L32.6478 48.8378C32.2435 48.6253 31.7604 48.6253 31.3561 48.8378L16.8574 56.4603C15.8393 56.9955 14.6493 56.131 14.8437 54.9973L17.6128 38.8527C17.69 38.4025 17.5407 37.9431 17.2136 37.6243L5.48389 26.1906C4.66021 25.3877 5.11473 23.9888 6.25303 23.8234L22.4631 21.468C22.9152 21.4023 23.3059 21.1184 23.5081 20.7088L30.7575 6.01992Z" fill="#FFC100"/>
                </svg>
                  <h1 className='consultation-profile-percentage'>4.5/5</h1>
                </div>
                <p className='consultant-profile-description'>Excellence Rating</p>
              </div>
            </div>
            <button className="consultaion-profile-consult-now-btn">Consult Now</button>
          </div>
          {/** consultant profile rating details */}
          <div className='consultant-profile-ratings-card'>
              <h1 className='consultant-profile-rating-heading'>Ratings & Reviews (273)</h1>
              <div className='consultant-profile-rating-container'>
                <div className='consultant-profile-rating-sub-container'>
                  <h3 className='consultant-profile-rating-sub-heading'>Ratings</h3>
                  <div className='consultant-profile-sub-bg-container'>
                  <div className='consultant-profile-rating-percentage-contaienr'>
                    <li className='consultant-profile-rating-percentage-item'>
                      <p className='consultant-profile-rating-number'>5</p>
                      <span className='consultant-profile-rating-percentage-bg-container'>
                        <span className='consultant-profile-rating-percentage-color-container'></span>
                      </span>
                    </li>
                    <li className='consultant-profile-rating-percentage-item'>
                      <p className='consultant-profile-rating-number'>4</p>
                      <span className='consultant-profile-rating-percentage-bg-container'>
                        <span className='consultant-profile-rating-percentage-color-container'></span>
                      </span>
                    </li>
                    <li className='consultant-profile-rating-percentage-item'>
                      <p className='consultant-profile-rating-number'>3</p>
                      <span className='consultant-profile-rating-percentage-bg-container'>
                        <span className='consultant-profile-rating-percentage-color-container'></span>
                      </span>
                    </li>
                    <li className='consultant-profile-rating-percentage-item'>
                      <p className='consultant-profile-rating-number'>2</p>
                      <span className='consultant-profile-rating-percentage-bg-container'>
                        <span className='consultant-profile-rating-percentage-color-container'></span>
                      </span>
                    </li>
                    <li className='consultant-profile-rating-percentage-item'>
                      <p className='consultant-profile-rating-number'>1</p>
                      <span className='consultant-profile-rating-percentage-bg-container'>
                        <span className='consultant-profile-rating-percentage-color-container'></span>
                      </span>
                    </li>
                  </div>
                  <div className='consultant-profile-rating-number-con'>
                    <div className='consultant-profile-rating-number'>
                      <p className='consultant-profile-rating'>4.5</p>
                      <img
                        src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1717302585/Star_uv7sem.svg"
                        className='consultant-profile-rating-star-img'
                        alt="star-img"
                      />
                    </div>
                    <p className='consultant-profile-reviews-number-container'>273 Reviews</p>
                  </div>
                  </div>
                </div>
                <hr className='consultant-profile-break-line' />
                <div className='consultant-profile-reviews-card'>
                  <h3 className='consultant-profile-review-card-heading'>Reviews</h3>
                  <div className='consultant-profile-reviews-card-list'>
                  {reviews.map(each => (
                    <ConsultantProfileReviewItem consultantProfileRatingDetails={each} />
                  ))}
                  </div>
                  <button className='consultant-profile-review-load-more-button'>Load More</button>
                </div>
              </div>
          </div>
        </div>
    </div>
  )
}

export default ConsultantProfile