import React from 'react'
import './index.css'

const ConsultantProfileReviewItem = (props) => {
  const {consultantProfileRatingDetails} = props
  const {userName,ratingImg,userReviewDesc,userReviewdDate,isHelpFull,notHelpfull} = consultantProfileRatingDetails
  return (
    <div className='consultant-profile-rating-item'>
        <div className='consultant-profile-rating-user-details'>
          <div>
            <h3 className='consultant-profile-rating-user-name'>{userName}</h3>
            <h3 className='consultant-profile-rating-user-name user-type'>Verified User</h3>
          </div>
          <img
            src={ratingImg}
            alt={userName}
            className='consultant-profile-rating-img'
          />
        </div>
        <p className='consultant-profile-rating-description'>{userReviewDesc}</p>
        <div className='consultant-profile-rating-helpful-container'>
          <div className='consultant-profile-rating-helpful-quesion'>
            <p className='consultant-profile-rating-helpful-description'>Helpful ?</p>
            <p className='consultant-profile-rating-helpful-description'>Yes ({isHelpFull})</p>
            <p className='consultant-profile-rating-helpful-description'>No ({notHelpfull})</p>
          </div>
          <p className='consultant-profile-rating-helpful-description rating-date'>{userReviewdDate}</p>
        </div>
        <h3 className='consultant-profile-rating-user-name user-type'>
          <img
           src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1717235546/CheckFilled_r1cxuj.svg"
           alt=""
          />
          Recommended
        </h3>
    </div>
  )
}

export default ConsultantProfileReviewItem