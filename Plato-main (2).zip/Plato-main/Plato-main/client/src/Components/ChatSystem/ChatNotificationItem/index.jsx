import React from 'react'
import './index.css'

const ChatNotificationItem = (props) => {
    const {chatNotificationDetails} = props
    const {profileImg,senderName,msg,time,unheardNotifications} = chatNotificationDetails
  return (
    <div className='chat-notification-item-card'>
        <div className='chat-notifivation-profile-container'>
            <img
                className='chat-notification-profile-img'
                src={profileImg}
                alt={senderName}
            />
            <div className='chat-notification-details-card'>
                <h4 className='chat-notification-sender-name'>{senderName}</h4>
                <p className='chat-notification-msg'>{msg}</p>
            </div>
        </div>

        <div className='chat-notification-time-container'>
            <div className='chat-notification-unheard-notification'>{unheardNotifications}</div>
            <p className='chat-notification-sent-time'>{time}</p>
        </div>
    </div>
  )
}

export default ChatNotificationItem