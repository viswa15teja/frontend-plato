import React from 'react'
import { IoChevronBackOutline } from "react-icons/io5";
import { IoMdMore } from "react-icons/io";
import './index.css'
const ChatNotificationItemDetailContainer = (props) => {
    const {chatProfileDetails} = props 
    // const {profileImg,name,status} = chatProfileDetails
  return (
    <div className='chat-notification-item-bg-container'>
        <div className='chat-notification-header-profile-container'>
            <button className='chat-notification-header-btn'><IoChevronBackOutline/></button>
            {/* <img
                src={profileImg}
                className='chat-notification-header-profile-img'
                alt={name}
            /> */}
            <img
                src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg"
                className='chat-notification-header-profile-img'
                alt="profile-img"
            />
            <div className='chat-notification-header-details-con'>
                {/* <h4 className='chat-notification-header-name'>{name}</h4>
                <p className='chat-notification-header-status'>{status}</p> */}
                <h4 className='chat-notification-header-name'>JohnDoe</h4>
                <p className='chat-notification-header-status'>Online</p>
            </div>
        </div>
        <div className='chat-notification-header-buttons-container'>
            <button className='chat-notification-header-btn'>
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <path d="M25.3327 7.99994H18.666C18.3124 7.99994 17.9733 8.14042 17.7232 8.39046C17.4732 8.64051 17.3327 8.97965 17.3327 9.33327C17.3327 9.68689 17.4732 10.026 17.7232 10.2761C17.9733 10.5261 18.3124 10.6666 18.666 10.6666H25.3327C25.6863 10.6666 26.0254 10.8071 26.2755 11.0571C26.5255 11.3072 26.666 11.6463 26.666 11.9999V24.9599L24.5727 23.0266C24.3268 22.7964 24.0029 22.6678 23.666 22.6666H11.9993C11.6457 22.6666 11.3066 22.5261 11.0565 22.2761C10.8065 22.026 10.666 21.6869 10.666 21.3333V18.6666C10.666 18.313 10.5255 17.9738 10.2755 17.7238C10.0254 17.4737 9.6863 17.3333 9.33268 17.3333C8.97906 17.3333 8.63992 17.4737 8.38987 17.7238C8.13983 17.9738 7.99935 18.313 7.99935 18.6666V21.3333C7.99935 22.3941 8.42078 23.4116 9.17092 24.1617C9.92107 24.9118 10.9385 25.3333 11.9993 25.3333H23.146L27.146 28.9733C27.3783 29.1914 27.681 29.3191 27.9993 29.3333C28.1822 29.3313 28.3631 29.2951 28.5327 29.2266C28.7712 29.1225 28.974 28.9509 29.1162 28.7329C29.2583 28.515 29.3336 28.2602 29.3327 27.9999V11.9999C29.3327 10.9391 28.9113 9.92166 28.1611 9.17151C27.411 8.42137 26.3935 7.99994 25.3327 7.99994ZM11.426 13.3333L13.7193 15.6399C13.8433 15.7649 13.9908 15.8641 14.1532 15.9318C14.3157 15.9995 14.49 16.0343 14.666 16.0343C14.842 16.0343 15.0163 15.9995 15.1788 15.9318C15.3413 15.8641 15.4887 15.7649 15.6127 15.6399C15.7377 15.516 15.8368 15.3685 15.9045 15.206C15.9722 15.0436 16.0071 14.8693 16.0071 14.6933C16.0071 14.5173 15.9722 14.343 15.9045 14.1805C15.8368 14.018 15.7377 13.8706 15.6127 13.7466L13.3327 11.4266C13.8915 10.5202 14.1912 9.47804 14.1993 8.41327C14.1993 6.88386 13.5918 5.41708 12.5103 4.33562C11.4289 3.25416 9.9621 2.64661 8.43268 2.64661C6.90327 2.64661 5.43649 3.25416 4.35503 4.33562C3.27357 5.41708 2.66602 6.88386 2.66602 8.41327C2.66601 9.93861 3.27104 11.4017 4.34836 12.4815C5.42569 13.5613 6.88735 14.1697 8.41268 14.1733C9.4751 14.1745 10.5175 13.884 11.426 13.3333ZM5.33268 8.41327C5.33242 8.00903 5.41243 7.60876 5.56807 7.23568C5.72371 6.8626 5.95188 6.52414 6.23935 6.23994C6.52749 5.94482 6.87173 5.71031 7.25184 5.55019C7.63194 5.39008 8.04023 5.30759 8.45268 5.30759C8.86513 5.30759 9.27342 5.39008 9.65353 5.55019C10.0336 5.71031 10.3779 5.94482 10.666 6.23994C10.9628 6.52713 11.1988 6.87107 11.3599 7.2513C11.5211 7.63153 11.6042 8.04029 11.6042 8.45327C11.6042 8.86625 11.5211 9.27501 11.3599 9.65525C11.1988 10.0355 10.9628 10.3794 10.666 10.6666C10.2328 11.1226 9.6708 11.4356 9.05506 11.564C8.43933 11.6924 7.79908 11.6301 7.2197 11.3853C6.64031 11.1405 6.14931 10.7249 5.81217 10.1939C5.47503 9.66291 5.30776 9.04176 5.33268 8.41327Z" fill="#222831"/>
                </svg>
            </button>
            <button className='chat-notification-header-btn'>
                <IoMdMore/>
            </button>
        </div>
    </div>
  )
}

export default ChatNotificationItemDetailContainer