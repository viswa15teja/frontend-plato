import React, { useState } from 'react'
import {v4 as uuidv4} from 'uuid'
import ChatNotificationItem from '../ChatNotificationItem'
import { FaArrowLeft,FaPlus } from "react-icons/fa";
import { LuSendHorizonal } from "react-icons/lu";
import './index.css'
import ChatNotificationItemDetailContainer from './../ChatNotificationItemDetailContainer/index';
const messages = [
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 2,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 2,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
    {
        id : uuidv4(),
        profileImg : 'https://res.cloudinary.com/dgl0v7vwf/image/upload/v1716985063/ae1e058c2ed75ab981a9f8bb62e96a13_rdonfe.jpg',
        senderName : 'Batman',
        msg : 'Hi, i am someone',
        time : '2.38pm',
        unheardNotifications : 0,
    },
]

const ChatScreen = () => {
    const [msgInput,setMsgInput] = useState("")
    const [userDetails,setUserDetails] = useState("")
  return (
    <div className='chat-screen-bg-container'>
        <div className='chat-notifications-container'>
            <div className='chat-notification-heading-container'>
                <button className='chat-notification-back-arrow'><FaArrowLeft/></button>
                <h3 className='chat-notification-heading'>My Chats</h3>
            </div>
            <div className="chat-notifications-card-container">
                {messages.map(each=>(
                    <ChatNotificationItem  chatNotificationDetails={each} />
                ))}
            </div>
        </div>
        <div className='chat-screen-notification-item-detail-container'>
            {/* <ChatNotificationItemDetailContainer chatProfileDetails={userDetails} /> */}
            <ChatNotificationItemDetailContainer />
            <div className='chat-screen-history'></div>
            <div className='chat-screen-msg-input-container'>
                <button className='chat-screen-msg-btn'><FaPlus/></button>
                <input
                    type='text'
                    placeholder='Type Something here...'
                    onChange={e=>setMsgInput(e.target.value)}
                    value={msgInput}
                    className="chat-screen-input-container"
                />
                <button className='chat-screen-msg-btn'><LuSendHorizonal/></button>
            </div>
        </div>
    </div>
  )
}

export default ChatScreen