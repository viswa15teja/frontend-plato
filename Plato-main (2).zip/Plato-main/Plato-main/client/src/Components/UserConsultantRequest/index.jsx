import FooterSeaWireFooter from "../FooterSeaWireFooter";
import "./index.css";
import consultation_request from '../Assets/consultation_request.jpeg';
import UserNavbar from './../User/UserNavbar';

const ConsultationRequest = () => {
  return (
    <>
      <UserNavbar />
      <div className="consultation-request-top-container">
        <div className="consultation-request-consultation-form">
          <h2 className="consultation-request-consultation-heading">Consultation Request</h2>
          <div className="consultation-request-form-group">
            <label htmlFor="topic1">Consultation Topic (Please tell us about what you want to consult on)</label>
            <textarea id="topic1" name="topic1" rows="4" className="input-field"></textarea>
          </div>
          <div className="consultation-request-form-group">
            <label htmlFor="industry">Industry:</label>
            <div className="input-with-icon">
              <select id="industry" name="industry" className="input-field">
                <option value="">Select Industry</option>
                <option value="technology">Technology</option>
                <option value="healthcare">Healthcare</option>
                <option value="finance">Finance</option>
                <option value="education">Education</option>
                <option value="manufacturing">Manufacturing</option>
                {/* Add more options as needed */}
              </select>
            
            </div>
          </div>
          <div className="consultation-request-form-group">
            <label htmlFor="function">Function:</label>
            <div className="input-with-icon">
              <select id="function" name="function" className="input-field">
                <option value="">Select Function</option>
                <option value="management">Management</option>
                <option value="engineering">Engineering</option>
                <option value="marketing">Marketing</option>
                <option value="sales">Sales</option>
                <option value="hr">Human Resources</option>
                {/* Add more options as needed */}
              </select>
            </div>
          </div>
          <div className="consultation-request-form-group">
            <label htmlFor="expertise">Expertise Area:</label>
            <div className="input-with-icon">
              <select id="expertise" name="expertise" className="input-field">
                <option value="">Select Expertise Area</option>
                <option value="strategy">Strategy</option>
                <option value="operations">Operations</option>
                <option value="finance">Finance</option>
                <option value="technology">Technology</option>
                <option value="innovation">Innovation</option>
                {/* Add more options as needed */}
              </select>
             
            </div>
          </div>
          <div className="consultation-request-form-group">
            <label htmlFor="additional-info">Additional Information:</label>
            <textarea id="additional-info" name="additional-info" rows="4" className="input-field" placeholder="Not strictly required"></textarea>
          </div>
          <div className="consultation-request-button">
            <button className="consultation-btn-request">Request Consultation</button>
          </div>
        </div>
        <div className="consultation-request-image">
          <img src={consultation_request} className="image1" alt="consultation" />
        </div>
      </div>
      <FooterSeaWireFooter />
    </>
  );
};

export default ConsultationRequest;
