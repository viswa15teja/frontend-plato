import React, { useState} from "react";
import './index.css'
import {v4 as uuidv4} from 'uuid'
import axios from "axios";
import {useNavigate} from "react-router-dom";

const availabities = [
  {
    id : uuidv4(),
    time : 'Daily',
    check : false,
  },
  {
    id : uuidv4(),
    time : 'All Weekdays',
    check : false,
  },
  {
    id : uuidv4(),
    time : 'Weekends Only',
    check : false,
  },
  {
    id : uuidv4(),
    time : 'Custom specify',
    check : false,
  },
]



const ConsultantCriticalDetails = () => {
  const [availability,setAvailability] = useState([])
  const [timeAvailability,setTimeAvailability] = useState("")

  const onSubmitDetailsForm = async (e) => {
    e.preventDefault();
  };

  return (
    <div className="details-form-bg-container">
        <img
          src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1714724348/Rectangle_51_izuu5g.png"
          alt="signin-img"
          className="detailsform-image"
        />
        <div className="details-form-contents-container">
        <div className="details-form-container">
          <h1 className="details-form-heading">Critical Details</h1>
          <form onSubmit={onSubmitDetailsForm}>
            <div className="marking-availability-container">
            <label className="details-form-label-el" htmlFor="">
                Mark your availability
              </label>
              {availabities.map(e=>(
                <div className="availability-con" key={e.id}>
                <input
                    type="checkbox"
                    id={e.time}
                    className="checkbox-availability"
                />
                <label className="availability-label-el" htmlFor={e.time} >{e.time}</label>
                </div>
              ))}
            </div>
            {/** time availability k*/}
            <div className="input-container">
              <label className="details-form-label-el" htmlFor="time-availabilty">
                Provide Time availability 
              </label>
              <input
                type="text"
                className="input-el"
                placeholder="Enter here"
                value={timeAvailability}
                onChange={(e) => setTimeAvailability(e.target.value)}
                id="time-availabilty"
              />
            </div>
            
            <button className="details-form-signup-btn" type="submit">
              Proceed
            </button>
          </form>
        </div>
        <div className="skip-step-container">
        <p className="or">Or</p>
        <h4 className="skip-for-now">Skip this step for now</h4>
        </div>
        </div>
    </div>
  );
};

export default ConsultantCriticalDetails;
