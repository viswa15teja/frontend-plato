import React, { useState, useEffect, useRef } from "react";
import "./index.css";
import { Select } from "antd";
import { v4 as uuidv4 } from "uuid";

import axios from "axios";
import { useNavigate } from "react-router-dom";

const DetailsForm = () => {
  //photo file
  //funtion or department
  //area of expertise or consulting
  //select input
  //diversity of experience
  //about consultant
  const [consultantDescription, setConsultantDescription] = useState("");
  //resume file
  const [resumeFile, setResumeFile] = useState(null);
  const [linkedIn, setLinkedIn] = useState("");
  const [feePerSession, setFeePerSession] = useState("");
  const [ctc, setCtc] = useState("");
  //supporting document file
  const [compensationDetails, setCompensationDetails] = useState(null);
  const [appointmentLetter, setAppointmentLetter] = useState(null);
  const navigate = useNavigate();
  //using useRef() hook
  const inputRefForResume = useRef(null);
  const inputRefForCompensationDetails = useRef(null);
  const inputRefForAppointemntLetter = useRef(null);

  const onSubmitDetailsForm = async (e) => {
    e.preventDefault();
    console.log(consultantDescription);
    console.log(resumeFile);
    console.log(linkedIn);
    console.log(feePerSession);
    console.log(ctc);
    console.log(compensationDetails);
    console.log(appointmentLetter);
  };

  //handling resume img click
  const handleResumeClick = () => {
    inputRefForResume.current.click();
  };

  //handling supporting docs img click
  const handleCompensationDetails = () => {
    inputRefForCompensationDetails.current.click();
  };

  const handleAppointemntLetter = () => {
    inputRefForAppointemntLetter.current.click();
  };

  return (
    <div className="details-form-bg-container">
      <img
        src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1714724348/Rectangle_51_izuu5g.png"
        alt="signin-img"
        className="detailsform-image"
      />
      <div className="details-form-contents-container">
        <div className="details-form-container">
          <h1 className="details-form-heading">Additional Details</h1>
          <form onSubmit={onSubmitDetailsForm}>
            {/** consultant description k*/}
            <div className="input-container">
              <label className="details-form-label-el">
                Tell people about yourself
              </label>
              <div className="consulant-description-container">
                <textarea
                  type="text"
                  className="details-form-textarea-el"
                  // placeholder="Search"
                  value={consultantDescription}
                  onChange={(e) => setConsultantDescription(e.target.value)}
                  maxLength={250}
                ></textarea>
                <p className="words-desc">0/250</p>
              </div>
            </div>
            {/** resume input k */}
            <div className="input-container">
              <label
                className="details-form-label-el resume-label"
                htmlFor="resume"
              >
                Resume
              </label>
              <div className="resume-container">
                {/**first container */}
                <div
                  className="resume-container-1"
                  onClick={handleResumeClick}
                  style={{ cursor: "pointer" }}
                >
                  <div>
                    <img
                      src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1715353768/file-add_vjkblk.png"
                      alt="file-upload-img"
                      className="file-upload-img"
                    />
                    <input
                      type="file"
                      ref={inputRefForResume}
                      style={{ display: "none" }}
                      // placeholder="Search"
                      // value={resumeFile}
                      onChange={(e) => setResumeFile(e.target.files[0])}
                      id="resume"
                    />
                  </div>
                  <p className="resume-description">Click to upload</p>
                </div>
                {/**second container */}
                <div className="resume-container-2">
                  <input
                    type="checkbox"
                    className="resume-checkbox"
                    checked={resumeFile !== null}
                  />
                  <div className="resume-description-container">
                    {resumeFile !== null ? (
                      <p className="resume-description-1">{resumeFile.name}</p>
                    ) : (
                      <p className="resume-description-1">resume.pdf</p>
                    )}
                    <p className="resume-description-2">upload complete</p>
                  </div>
                </div>
              </div>
            </div>
            {/** linkedin profile k*/}
            <div className="input-container">
              <label className="details-form-label-el" htmlFor="linkedin">
                Linkedin profile
              </label>
              <input
                type="text"
                className="input-el"
                placeholder="https://linkedin.com"
                value={linkedIn}
                onChange={(e) => setLinkedIn(e.target.value)}
                id="linkedin"
              />
            </div>
            {/**fee per session k*/}
            <div className="input-container">
              <label className="details-form-label-el" htmlFor="fee">
                Fee per session (a session is typically 1hr - 1.5hr)
              </label>
              <input
                type="text"
                className="input-el"
                placeholder="Enter here (in rupees)"
                value={feePerSession}
                onChange={(e) => setFeePerSession(e.target.value)}
                id="fee"
              />
            </div>
            {/** last or current ctc k*/}
            <div className="input-container">
              <label className="details-form-label-el" htmlFor="ctc">
                Current/Last drawn CTC value (annual)
              </label>
              <input
                type="text"
                className="input-el"
                placeholder="Enter here (in rupees)"
                value={ctc}
                onChange={(e) => setCtc(e.target.value)}
                id="ctc"
              />
            </div>
            {/** Compensation details k*/}
            <div className="input-container">
              <label
                className="details-form-label-el resume-label"
                htmlFor="compensation-details"
              >
                Compensation Details
              </label>
              <div className="resume-container">
                {/**first container */}
                <div
                  className="resume-container-1"
                  onClick={handleCompensationDetails}
                  style={{ cursor: "pointer" }}
                >
                  <div>
                    <img
                      src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1715353768/file-add_vjkblk.png"
                      alt="file-upload-img"
                      className="file-upload-img"
                    />
                    <input
                      type="file"
                      ref={inputRefForCompensationDetails}
                      style={{ display: "none" }}
                      // value={compensationDetails}
                      onChange={(e) =>
                        setCompensationDetails(e.target.files[0])
                      }
                      id="compensation-details"
                    />
                  </div>
                  <p className="resume-description">Click to upload</p>
                </div>
                {/**second container */}
                <div className="resume-container-2">
                  <input
                    type="checkbox"
                    className="resume-checkbox"
                    checked={compensationDetails !== null}
                  />
                  <div className="resume-description-container">
                    {compensationDetails !== null ? (
                      <p className="resume-description-1">
                        {compensationDetails.name}
                      </p>
                    ) : (
                      <p className="resume-description-1">
                        compensationDetails.pdf
                      </p>
                    )}
                    <p className="resume-description-2">upload complete</p>
                  </div>
                </div>
              </div>
            </div>
            {/** appointement letter/ Experience/ Relieving letter k*/}
            <div className="input-container">
              <label
                className="details-form-label-el resume-label"
                htmlFor="appointment-letter"
              >
                Appointment letter/ Experience/ Relieving letter
              </label>
              <div className="resume-container">
                {/**first container */}
                <div
                  className="resume-container-1"
                  onClick={handleAppointemntLetter}
                  style={{ cursor: "pointer" }}
                >
                  <div>
                    <img
                      src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1715353768/file-add_vjkblk.png"
                      alt="file-upload-img"
                      className="file-upload-img"
                    />
                    <input
                      type="file"
                      ref={inputRefForAppointemntLetter}
                      style={{ display: "none" }}
                      // value={appointmentLetter}
                      onChange={(e) => setAppointmentLetter(e.target.files[0])}
                      id="appointment-letter"
                    />
                  </div>
                  <p className="resume-description">Click to upload</p>
                </div>
                {/**second container */}
                <div className="resume-container-2">
                  <input
                    type="checkbox"
                    className="resume-checkbox"
                    checked={appointmentLetter !== null}
                  />
                  <div className="resume-description-container">
                    {appointmentLetter !== null ? (
                      <p className="resume-description-1">
                        {appointmentLetter.name}
                      </p>
                    ) : (
                      <p className="resume-description-1">
                        appointmentletter.pdf
                      </p>
                    )}
                    <p className="resume-description-2">upload complete</p>
                  </div>
                </div>
              </div>
            </div>
            <button className="details-form-signup-btn" type="submit">
              Signup
            </button>
          </form>
        </div>
        <div className="skip-step-container">
          <p className="or">Or</p>
          <h4 className="skip-for-now">Skip this step for now</h4>
        </div>
      </div>
    </div>
  );
};

export default DetailsForm;
