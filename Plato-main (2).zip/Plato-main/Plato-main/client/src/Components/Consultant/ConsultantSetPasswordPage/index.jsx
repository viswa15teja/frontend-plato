import React, { useState } from "react";
import { IoEye } from "react-icons/io5";
import { IoEyeOff } from "react-icons/io5";
import "./index.css";

const UserSetPasswordPage = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [passwordHidden, setPasswordHidded] = useState(true);
  const [confirmPasswordHidden, setConfirmPasswordHidden] = useState(true);

  const passwordType = passwordHidden ? "password" : "text";
  const confirmPasswordType = confirmPasswordHidden ? "password" : "text";
  const passwordIcon = passwordHidden ? (
    <IoEye size={26} />
  ) : (
    <IoEyeOff size={26} />
  );
  const confirmPasswordIcon = confirmPasswordHidden ? (
    <IoEye size={26} />
  ) : (
    <IoEyeOff size={26} />
  );

  return (
    <div className="set-password-bg-container">
      <img
        src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1714724348/Rectangle_51_izuu5g.png"
        alt="signin-img"
        className="signin-image"
      />
      <div className="set-password-details-bg-container">
        <h1 className="set-password-heading">Set Password</h1>
        <div className="input-container">
          <label className="set-password-label-el" htmlFor="password">
            Password
          </label>
          <div className="password-container">
            <input
              type={passwordType}
              className="password-input"
              placeholder="********"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              id="password"
            />
            <button
              onClick={() => setPasswordHidded(!passwordHidden)}
              className="password-btn"
            >
              {passwordIcon}
            </button>
          </div>
        </div>
        <div className="input-container">
          <label className="details-form-label-el" htmlFor="password">
            Re-Confirm
          </label>
          <div className="password-container">
            <input
              type={confirmPasswordType}
              className="password-input"
              placeholder="********"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              id="password"
            />
            <button
              onClick={() => setConfirmPasswordHidden(!confirmPasswordHidden)}
              className="password-btn"
            >
              {confirmPasswordIcon}
            </button>
          </div>
        </div>
        <div className="password-rules-list">
          <li className="password-rule">
            Passwords must be a minimum of 10 characters long.
          </li>
          <li className="password-rule">
            Passwords must include at least one uppercase letter, one lowercase
            letter, <br /> one number, and one special character.
          </li>
          <li className="password-rule">
            Avoid common patterns or sequences, such as "123456" or "password."
          </li>
        </div>
        <button className="set-password-signup-btn" type="button">
          Sign up
        </button>
      </div>
    </div>
  );
};

export default UserSetPasswordPage;
