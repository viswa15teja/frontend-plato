import React, { useState } from "react";
import "./index.css";
import { useNavigate } from "react-router-dom";

const SignInPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const onClickSignIn=async(email,password)=> {
    try {
      const response = await fetch('http://localhost:5000/consultant/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email:email,password:password }),
        
      });
      console.log(response);
      if(response.status===202) {
        //have to redirect to the consultant homepage
        navigate('');
      }
    } catch (error) {
      console.error("Error:", error);
    }
  }

  return (
    <div className="new-account-page-bg-container">
      <div className="new-account-page-main-container">
        <img
          src="https://res.cloudinary.com/dgl0v7vwf/image/upload/v1714724348/Rectangle_51_izuu5g.png"
          alt="signin-img"
          className="signin-image"
        />
        <div className="new-account-page-details-bg-container">
          <div className="new-account-page-details-main-container">
            <h1 className="new-account-page-details-heading">Welcome Back!</h1>
            <div className="input-container">
              <label
                className="new-account-page-details-label-el"
                htmlFor="email"
              >
                Email
              </label>
              <input
                type="email"
                className="new-account-page-details-input-el"
                placeholder="johndoe@email.net"
                id="email"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
            </div>
            <div className="input-container">
              <label
                className="new-account-page-details-label-el"
                htmlFor="password"
              >
                Password
              </label>
              <input
                type="password"
                className="new-account-page-details-input-el"
                placeholder="********"
                id="password"
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
            </div>
            <button className="new-account-page-details-proceed-btn" type="button" onClick={()=>onClickSignIn(email,password)}>
              Sign in
            </button>
            <p className="forgot-password-description">Forgot Password?</p>
          </div>
          <div>
            <p className="new-account-page-details-description">
              Don't have an account? <span className="span">Sign up</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignInPage;
